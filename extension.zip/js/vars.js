const WITHDRAW_LINK = 'https://docs.google.com/forms/d/e/1FAIpQLSdvlulrkbzNGK1AIZda6JhHz8jxbSlPvzN07Cn_1Sq0S3RBlA/viewform?usp=pp_url&entry.788480040=';
const BALANCE_LINK = 'http://api.moneta.space/info/balance/?user=';
const KEY = 'JnJvQhadm6i3FbiPYpyanThK9Ia5ofAX';
const bg = chrome.extension.getBackgroundPage();